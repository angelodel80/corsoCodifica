package com.thaiopensource.datatype.xsd;

class AnyAtomicTypeDatatype extends TokenDatatype {
  AnyAtomicTypeDatatype() {
    super(WHITE_SPACE_PRESERVE);
  }
}
