package com.thaiopensource.datatype.xsd;

class UntypedAtomicDatatype extends TokenDatatype {
  UntypedAtomicDatatype() {
    super(WHITE_SPACE_PRESERVE);
  }
}
