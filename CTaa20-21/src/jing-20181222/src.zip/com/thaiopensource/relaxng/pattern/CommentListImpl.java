package com.thaiopensource.relaxng.pattern;

import com.thaiopensource.relaxng.parse.BuildException;
import com.thaiopensource.relaxng.parse.CommentList;
import org.xml.sax.Locator;

public class CommentListImpl implements CommentList<Locator> {
  public void addComment(String value, Locator loc) throws BuildException {
  }
}
