package com.thaiopensource.relaxng.parse.compact;

class EOFException extends Exception {
}
