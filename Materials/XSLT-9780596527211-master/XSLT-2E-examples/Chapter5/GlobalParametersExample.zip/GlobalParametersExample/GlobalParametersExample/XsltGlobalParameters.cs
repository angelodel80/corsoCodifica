using System;
using System.Text;
using System.Xml;
using System.Xml.Xsl;

namespace com.oreilly.xslt
{
  class XsltGlobalParameters
  {
    static void Main(string[] args)
    {
      // Create the stylesheet object and the XMLWriter that
      // writes the output to a file
      XslCompiledTransform stylesheet = new XslCompiledTransform();
      XmlTextWriter xWriter =
          new XmlTextWriter(args[2], Encoding.UTF8);

      // Use an XsltSettings object that allows executing scripts
      // (we need this for extensions), then load the stylesheet
      XsltSettings settings = new XsltSettings(true, true);
      stylesheet.Load(args[1], settings, new XmlUrlResolver());

      // We pass global parameters to the stylesheet with an
      // XsltArgumentList object.
      XsltArgumentList argList = new XsltArgumentList();
      argList.AddParam("startX", "", 50);
      argList.AddParam("baseColor", "", "magenta");

      // With everything in place, we call the Transform() method
      // to do the work...
      stylesheet.Transform(args[0], argList, xWriter);
    }
  }
}