/**
 * TheTheCollation.java
 * Created on Sep 21, 2007 by Skippy
 */


import java.util.Comparator;

/**
 * @author Skippy
 *
 */
public class TheTheCollation implements Comparator<String>
{
    public int compare(String first, String second)
    {
        String arg1, arg2;
        System.out.println("first = " + first + " second = " + second);

        if (first.length() >= 4 && 
            first.substring(0,4).equalsIgnoreCase("The "))
            arg1 = first.substring(4);
        else 
            arg1 = first;

        if (second.length() >= 4 && 
            second.substring(0,4).equalsIgnoreCase("The "))
            arg2 = second.substring(4);
        else
            arg2 = second;

        System.out.println("arg1 = " + arg1 + " arg2 = " + arg2);

        return arg1.compareTo(arg2);
    }

    public static void main(String args[])
    {
        TheTheCollation ttc = new TheTheCollation();
        ttc.compare("The Clash", "dB's");
    }
}
