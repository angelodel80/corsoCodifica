/*
 * Main.cs 
 * Created on Nov 22, 2006 by Skippy 
 */

using System;
using System.Text;
using System.Xml;
using System.Xml.Xsl;

namespace com.oreilly.xslt
{
  class MainClass
  {
    static void Main(string[] args)
    {
      if (args.Length < 3)
      {
        System.Console.WriteLine("\nUsage: HiddenWordExample xml-file " +
          "xsl-file output-file");
        System.Console.WriteLine("\n  Example: HiddenWordExample " +
          "blank.xml hidden-word-test.xsl results.html");
      }
      else
      {
        // Create the stylesheet object and the XMLWriter that
        // writes the output to a file
        XslCompiledTransform stylesheet = new XslCompiledTransform();
        XmlTextWriter xWriter =
            new XmlTextWriter(args[2], Encoding.UTF8);

        // Use an XsltSettings object that allows executing scripts
        // (we need this for extensions), then load the stylesheet
        XsltSettings settings = new XsltSettings(true, true);
        stylesheet.Load(args[1], settings, new XmlUrlResolver());

        // Create an extension object
        HiddenWord hw = new HiddenWord();

        // We set up the extension function with an XsltArgumentList object.
        XsltArgumentList argList = new XsltArgumentList();
        argList.AddExtensionObject("http://www.oreilly.com/xslt", hw);

        // With everything in place, we call the Transform() method
        // to do the work...
        stylesheet.Transform(args[0], argList, xWriter);
      }
    }
  }
}
