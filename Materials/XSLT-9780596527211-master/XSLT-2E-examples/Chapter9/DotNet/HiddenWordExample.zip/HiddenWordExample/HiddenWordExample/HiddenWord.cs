/*
 * HiddenWord.cs 
 * Created on Nov 22, 2006 by Doug Tidwell 
 */
 
using System;
using System.Text;
using System.Xml;
using System.Xml.Xsl;
using System.Drawing;

// This class creates a JPEG that contains a hidden word.

namespace com.oreilly.xslt
{
  class HiddenWord
  {
    // Three fonts likely to be installed on a Windows system...
    // If you want to generate hidden words in a non-Latin language, 
    // you'll need to change the font names.
    private static String[] fontNames = { "Arial", "Times", "Verdana" };

    // createJPEG() is the name of the extension function.
    public int createJPEG(String outputFilename, 
                          String secretWord, Double dFontSize,
                          Double dWidth, Double dHeight)
    {
      int rc = 0;

      int fontSize = (int)dFontSize;
      int width = (int)dWidth;
      int height = (int)dHeight;

      Random r = new Random();

      String fontName = fontNames[r.Next(fontNames.Length)];

      // Create a new Bitmap.  We'll draw our text and graphics 
      // onto the Bitmap, then write it out to a JPEG file.
      Bitmap pic = new Bitmap(width, height);
      Graphics context = Graphics.FromImage(pic);

      // First, fill the graphic with a white background
      SolidBrush brush = new SolidBrush(Color.White);
      context.FillRectangle(brush, 0, 0, width, height);

      // Load the randomly-chosen font
      Font currentFont = new Font(fontName, fontSize, FontStyle.Bold);

      // Get the size of the word in the current font.  If it's too big
      // for the word to fit into the graphic, reduce the font size 
      // until it fits.
      SizeF textSize = context.MeasureString(secretWord, currentFont);
      float textWidth = textSize.Width;

      while (textWidth > width && fontSize > 2)
      {
        fontSize -= 2;
        currentFont = new Font(fontName, fontSize, FontStyle.Bold);
        textSize = context.MeasureString(secretWord, currentFont);
        textWidth = textSize.Width;
      }
      if (fontSize < 1)
        currentFont = new Font(fontName, 12, FontStyle.Bold);

      float textHeight = textSize.Height;
      brush.Color = Color.Black;

      // Now draw the string onto the bitmap.  We center the text 
      // by using the dimensions of the bitmap and the dimensions
      // of the string as drawn in the current font. 
      context.DrawString(secretWord, currentFont, brush,
          (width - textWidth) / 2, (height - textHeight) / 2);

      // Now we draw some lines on the bitmap.  We generate the start 
      // and endpoints of the lines at random.
      Pen pen = new Pen(Color.Black, (float)2);
      for (int i = 0; i < width / 30; i++)
        context.DrawLine(pen, 0, r.Next(height), width, r.Next(width));

      int numLines = Math.Max(height, width) / 30;
      for (int i = 0; i < numLines; i++)
      {
        int nextX = r.Next(width);
        context.DrawLine(pen, nextX, 0, nextX, height);
        int nextY = r.Next(height);
        context.DrawLine(pen, 0, nextY, width, nextY);
      }

      for (int i = 0; i < height / 20; i++)
        context.DrawLine(pen, r.Next(width), 0, r.Next(width), height);

      // Now we've drawn everything on the bitmap, so we write it out
      // to a file, using the JPEG format
      pic.Save(outputFilename, System.Drawing.Imaging.ImageFormat.Jpeg);

      return rc;
    }
  }
}