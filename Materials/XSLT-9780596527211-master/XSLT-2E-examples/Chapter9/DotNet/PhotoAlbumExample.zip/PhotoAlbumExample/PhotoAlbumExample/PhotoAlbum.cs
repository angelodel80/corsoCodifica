/* 
 * PhotoAlbum.cs
 * Created on Nov 28, 2006 by Doug Tidwell
 */

using System;
using System.IO;
using System.Text;
using System.Xml;

// This class creates a photo album with all of the images in a 
// given directory.
namespace com.oreilly.xslt
{
  class PhotoAlbum
  {
    // getPhotoListing is the name of the extension function.  Notice 
    // that it returns an XMLNode; that node is inserted into the 
    // output tree. 
    public XmlNode getPhotoListing(String dirName,
                                   String imgPerRow,
                                   String incFilenames)
    {
      // For parameters, we get the name of the directory, the number 
      // of images per row, and whether the names of the files should 
      // be displayed.
      int imagesPerRow = int.Parse(imgPerRow);
      Boolean includeFilenames = (incFilenames.Equals("yes"));

      // We're building a DOM tree, effectively, so we create some 
      // elements beforehand.
      XmlElement anchorEl, breaklineEl, imageEl, spanEl, 
          tableEl, tableDataEl, tableRowEl;
      XmlNode textNode;

      XmlDocument doc = new XmlDocument();
      XmlDocumentFragment df = doc.CreateDocumentFragment();
      tableEl = doc.CreateElement("table");
      tableEl.SetAttribute("border", "3");
      tableEl.SetAttribute("cellpadding", "5");

      Boolean directoryExists = true;

      System.Collections.ArrayList allGraphicsFiles =
          new System.Collections.ArrayList();

      // We add all of the JPEG, PNG, GIF and BMP files in the
      // specified directory.  Windows isn't case sensitive, so 
      // the code is slightly simpler than the Java version.
      try
      {
        allGraphicsFiles.InsertRange(allGraphicsFiles.Count,
            System.IO.Directory.GetFiles(dirName, "*.jpg"));
        allGraphicsFiles.InsertRange(allGraphicsFiles.Count,
            System.IO.Directory.GetFiles(dirName, "*.jpeg"));
        allGraphicsFiles.InsertRange(allGraphicsFiles.Count,
            System.IO.Directory.GetFiles(dirName, "*.png"));
        allGraphicsFiles.InsertRange(allGraphicsFiles.Count,
            System.IO.Directory.GetFiles(dirName, "*.gif"));
        allGraphicsFiles.InsertRange(allGraphicsFiles.Count,
            System.IO.Directory.GetFiles(dirName, "*.bmp"));
      }

      // Return an error message if the directory doesn't exist
      catch (System.IO.DirectoryNotFoundException dnfe)
      {
        directoryExists = false;
        tableRowEl = doc.CreateElement("tr");
        tableDataEl = doc.CreateElement("td");
        tableDataEl.SetAttribute("style", "font-weight: bold; " + 
            "font-size: 150%;");
        textNode = doc.CreateTextNode("The directory ");
        tableDataEl.AppendChild(textNode);
        spanEl = doc.CreateElement("span");
        spanEl.SetAttribute("style", "font-family: monospace;");
        spanEl.AppendChild(doc.CreateTextNode(dirName));
        tableDataEl.AppendChild(spanEl);
        textNode = doc.CreateTextNode(" doesn't exist!");
        tableDataEl.AppendChild(textNode);
        tableRowEl.AppendChild(tableDataEl);
        tableEl.AppendChild(tableRowEl);
        df.AppendChild(tableEl);
      }

      int numFiles = allGraphicsFiles.Count;

      if (directoryExists)
      {
        // Return an error message if the directory doesn't contain
        // any images
        if (numFiles == 0)
        {
          tableRowEl = doc.CreateElement("tr");
          tableDataEl = doc.CreateElement("td");
          tableDataEl.SetAttribute("style", "font-weight: bold; " + 
              "font-size: 150%;");
          textNode = doc.CreateTextNode("The directory ");
          tableDataEl.AppendChild(textNode);
          spanEl = doc.CreateElement("span");
          spanEl.SetAttribute("style", "font-family: monospace;");
          spanEl.AppendChild(doc.CreateTextNode(dirName));
          tableDataEl.AppendChild(spanEl);
          textNode = 
              doc.CreateTextNode(" doesn't contain any images!");
          tableDataEl.AppendChild(textNode);
          tableRowEl.AppendChild(tableDataEl);
          tableEl.AppendChild(tableRowEl);
          df.AppendChild(tableEl);
        }
        
        // We've got some images, so let's process 'em...
        else
        {
          // First we create a table row for the header.
          tableRowEl = doc.CreateElement("tr");
          tableDataEl = doc.CreateElement("td");
          tableDataEl.SetAttribute("colspan", imgPerRow);
          tableDataEl.SetAttribute("style", "font-weight: bold; " + 
              "background: #CCCCCC; font-size: 150%;");
          tableDataEl.AppendChild(doc.CreateTextNode("Photos from "));
          spanEl = doc.CreateElement("span");
          spanEl.SetAttribute("style", "font-family: monospace;");
          spanEl.AppendChild(doc.CreateTextNode(dirName + ":"));
          tableDataEl.AppendChild(spanEl);
          tableRowEl.AppendChild(tableDataEl);
          tableEl.AppendChild(tableRowEl);

          // Now we process all of the files.  The emptyColumnNotCreated 
          // flag tells us whether the blank cell has been created.  
          // If there are five images per row and there are 47 images, 
          // the last row will contain a blank cell with a colspan of 3.  
          // We only create that blank cell once.
          int filesProcessed = 0;
          Boolean emptyColumnNotCreated = true;

          // We look through all of the files
          while (filesProcessed < numFiles)
          {
            tableRowEl = doc.CreateElement("tr");

            // Process the next {imagesPerRow} images
            for (int i = 0; i < imagesPerRow; i++)
            {
              if (filesProcessed < numFiles)
              {
                tableDataEl = doc.CreateElement("td");
                tableDataEl.SetAttribute("style", "text-align: center;");
                String qualifiedFilename = "file:\\\\" + 
                    allGraphicsFiles[filesProcessed];
                anchorEl = doc.CreateElement("a");
                imageEl = doc.CreateElement("img");
                imageEl.SetAttribute("src", qualifiedFilename);
                imageEl.SetAttribute("width", "100px");
                imageEl.SetAttribute("height", "130px");
                imageEl.SetAttribute("border", "0");
                anchorEl.AppendChild(imageEl);
                tableDataEl.AppendChild(anchorEl);

                if (includeFilenames)
                {
                  breaklineEl = doc.CreateElement("br");
                  tableDataEl.AppendChild(breaklineEl);

                  // We use FileInfo to get the filename without the path.
                  FileInfo fi = 
                    new FileInfo((String)allGraphicsFiles[filesProcessed]);
                  spanEl = doc.CreateElement("span");
                  spanEl.SetAttribute("style", "font-family: monospace;");
                  spanEl.AppendChild(doc.CreateTextNode(fi.Name));
                  tableDataEl.AppendChild(spanEl);
                }
                tableRowEl.AppendChild(tableDataEl);
                filesProcessed++;
              }

              // If we've processed all of the files and we haven't 
              // created the empty column, we'll do that now.
              else if (emptyColumnNotCreated)
              {
                tableDataEl = doc.CreateElement("td");
                Int32 colspan = (imagesPerRow - i);
                tableDataEl.SetAttribute("colspan", colspan.ToString());
                tableDataEl.SetAttribute("style", "background: #CCCCCC;");
                tableRowEl.AppendChild(tableDataEl);
                emptyColumnNotCreated = false;
              }
            }

            // Throughout this code, we create elements and append them to 
            // the appropriate parent element. 
            tableEl.AppendChild(tableRowEl);
          }
          df.AppendChild(tableEl);
        }
      }

      // Once we've finished, we have a node set that contains all of the 
      // HTML elements we need.  That is returned to the caller, which 
      // then inserts those nodes into the output stream. 
      return df;
    }
  }
}
